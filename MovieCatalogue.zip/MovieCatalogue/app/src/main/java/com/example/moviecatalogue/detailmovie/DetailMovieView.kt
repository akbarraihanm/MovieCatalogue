package com.example.moviecatalogue.detailmovie

import com.example.moviecatalogue.model.DetailMovie

interface DetailMovieView {
    fun showDetailMovieItem(detailMovieData : DetailMovie)
}
