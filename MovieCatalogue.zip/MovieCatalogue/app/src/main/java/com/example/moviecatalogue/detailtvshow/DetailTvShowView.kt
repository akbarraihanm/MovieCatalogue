package com.example.moviecatalogue.detailtvshow

import com.example.moviecatalogue.model.DetailTvShow

interface DetailTvShowView {
    fun showDataDetailTvShow(dataDetailTvShow : DetailTvShow)
}
